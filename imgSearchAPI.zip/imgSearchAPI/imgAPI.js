//accessing the html document elements
let searchForm = document.querySelector("form");
let imageContainer = document.querySelector(".image-container");
let searchBar = document.querySelector("#search-bar");
let loadMoreBtn = document.querySelector(".loadMoreBtn");

//creating a constant for the access key required to get authorization from api
const accessKey = "";

//creating a function for fetching images(data) from the api & styling the images too
let page = 1;
const fetchImages = async (imgSearch,pageNo)=>{
    try{
        if(pageNo === 1){
            imageContainer.innerHTML = "";
        };
        const baseURL = `https://api.unsplash.com/search/photos?query=${imgSearch}&per_page=28&page=${pageNo}&client_id=${accessKey}`; //url of the api with the search keyword and access key
        const response = await fetch(baseURL); 
        const data = await response.json(); //converting the response of api get request into json 
        if(data.results.length>0){
            data.results.forEach((image) =>{ 
                const imgBox = document.createElement('div');
                imgBox.classList.add('imgBox');
                imgBox.innerHTML = `<img src="${image.urls.regular}"/>` //getting the url of images with parameter regular(size) from api response dataset
                
                const overlay = document.createElement('div'); // creating a div in image box for styling an overlay
                overlay.classList.add('overlay');
        
                const overlayText = document.createElement('h3');
                overlayText.innerText = `${image.alt_description}`;
        
                overlay.appendChild(overlayText); //adding the image description using heading when overlay appears
                imgBox.appendChild(overlay); //adding the styled overlay div to image box
                imageContainer.appendChild(imgBox); //adding the images in image container div on last places
            });
            if(data.total_pages === pageNo){
                loadMoreBtn.style.display = "none";
            }else{
                loadMoreBtn.style.display = "block";
            }
        }else{
            imageContainer.innerHTML = `<h2>No image found, Please enter a valid search</h2>`;
            if(loadMoreBtn.style.display === "block"){
                loadMoreBtn.style.display = "none";
            }
        }
    }catch(error){
        imageContainer.innerHTML = `<h2>Failed fetching images, pls try again later</h2>`;
    }
}

searchForm.addEventListener('submit',(e)=>{
    e.preventDefault(); //prevents our form from auto-submission
    const imgSearch = searchBar.value.trim(); //fetching the user input into javascript and trimming any unwanted spaces

    if(imgSearch !== ''){
        page = 1;
        fetchImages(imgSearch, page);
    }
    else{
        imageContainer.innerHTML = `<h2>Please enter a valid search (-_-)</h2>`;
        if(loadMoreBtn.style.display === "block"){
            loadMoreBtn.style.display = "none";
        }
    }
});

loadMoreBtn.addEventListener("click",()=>{
    fetchImages(searchBar.value.trim(),++page)
})